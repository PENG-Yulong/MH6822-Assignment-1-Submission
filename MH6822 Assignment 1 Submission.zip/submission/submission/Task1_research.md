# Task 1 — Selection and Research

## 1\. Regulated Entity: Standard Chartered Bank

**Full legal name (US):** Standard Chartered Bank, New York Branch  
**Full legal name (Singapore):** Standard Chartered Bank (Singapore) Limited  
**Parent:** Standard Chartered PLC, incorporated in England and Wales (LSE: STAN)

### Why this entity?

Standard Chartered is one of the few major banks with genuinely deep operational roots in *both* the United States and Singapore simultaneously, not merely a representative office in one jurisdiction. Its Singapore subsidiary is a full domestic bank with a Qualifying Full Bank (QFB) licence under the Banking Act 1970 (Cap. 19), and is regulated by the Monetary Authority of Singapore (MAS). Its US New York Branch is regulated by the Office of the Comptroller of the Currency (OCC), the Federal Reserve Bank of New York, and the New York Department of Financial Services (NYDFS). This dual footprint means that real compliance decisions about model risk management and credit scoring must satisfy two materially different regulatory regimes simultaneously.

Additionally, Standard Chartered has been the subject of significant regulatory action in both jurisdictions: US enforcement actions related to sanctions violations (2012, 2019) and MAS supervisory oversight of its consumer banking AI practices, which makes it a more useful case study than a generic hypothetical bank.



## 2\. Domain: AI Model Risk Management Applied to Credit Scoring

### What the domain is

Standard Chartered, like all major consumer and SME lenders, uses statistical and machine-learning models to make or assist credit decisions, including loan approvals, limit-setting, pricing, and collections prioritisation. As these models have become more complex (gradient boosted trees, neural networks), the question of how to govern them (validating their accuracy, detecting drift, ensuring fairness, and producing explainable outputs) has become the central tension in RegTech.

I have chosen **AI Model Risk Management for Credit Scoring** because:

1. It is live and operationally material at Standard Chartered in both jurisdictions.
2. The regulatory divergence between the US and Singapore is stark and well-documented.
3. The Trump-era OCC Bulletin 2026-13 and the MAS 2024 AI Model Risk Management consultation paper represent genuinely opposite political choices on key questions (GenAI scope, explainability mandate, board accountability).

### Key regulatory divergence: the political choices made

The table below captures the choices legislators and regulators have made, not technical differences but normative ones.

|Dimension|United States|Singapore|
|-|-|-|
|**GenAI scope**|OCC 2026-13 **explicitly excludes** generative AI models from model risk management requirements. This is a deliberate deregulatory choice: the Trump administration argued GenAI is too novel for prescriptive rules.|MAS 2024 AI MRM paper **includes all AI**, including generative AI. MAS takes the view that novelty increases, not decreases, the need for governance.|
|**Adverse action explainability**|CFPB's 2026 Reg B rewrite (finalised largely as proposed) accepts "principal reasons" as sufficient for AI-driven denials. The CFPB under the Trump administration walked back the Biden-era guidance that required lenders to probe AI black boxes for digital redlining.|MAS FEAT Principles require that AI-driven credit decisions be explainable to the affected individual in terms they can understand, and that the institution maintain an audit trail sufficient for MAS examination.|
|**Board accountability**|OCC 2026-13 requires senior management oversight but does not mandate board-level approval for model deployment.|MAS 2024 requires board-level sign-off for material AI models and quarterly board reporting on model risk.|
|**Validation frequency**|OCC 2026-13: annual validation for material models.|MAS 2024: minimum semi-annual, or event-triggered (data drift, regulatory change, significant performance deterioration).|
|**Fair lending standard**|ECOA / Regulation B: 4/5ths (80%) rule — if a protected group's approval rate is below 80% of the most-favoured group, disparate impact is presumed. The Trump-era CFPB has signalled reduced enforcement of disparate-impact theory.|MAS FEAT Fairness Principle: demographic parity and equal opportunity are both assessed; no single threshold rule, but MAS expects documented methodology and board attestation.|
|**PDPA / data privacy**|No federal equivalent; state-level (CCPA in California). For Standard Chartered NY Branch: NYDFS Part 500 (cybersecurity).|Singapore PDPA 2012 (amended 2020) applies to personal data used in credit models. Data used for model training requires documented lawful basis.|

### Why these political choices matter for a RegTech tool

The OCC 2026-13 GenAI exclusion is not a technicality. It means a tool designed purely for US compliance can legally ignore generative AI model used in underwriting. The same tool deployed at a Singapore subsidiary must govern that model. This creates a genuine design fork that a jurisdiction-unaware tool would handle incorrectly by omission, not merely a configuration difference, but a scope difference

**References:**

* OCC Bulletin 2026-13: https://www.occ.treas.gov/news-issuances/bulletins/2026/bulletin-2026-13.html
* CFPB Reg B Final Rule 2026: https://www.consumerfinancialserviceslawmonitor.com/2026/04/cfpb-finalizes-regulation-b-subpart-a-rule-largely-as-proposed/
* Biden-era CFPB AI credit guidance (contrast): https://www.consumerfinance.gov/about-us/newsroom/cfpb-issues-guidance-on-credit-denials-by-lenders-using-artificial-intelligence/
* MAS 2024 AI Model Risk Management paper: https://www.mas.gov.sg/regulation/guidance (search "Model Risk Management 2024")
* MAS FEAT Principles 2018: https://www.mas.gov.sg/\~/media/MAS/News%20and%20Publications/Monographs%20and%20Information%20Papers/FEAT%20Principles%20Final.pdf
* EU AI Act (for context on global direction): https://www.europarl.europa.eu/RegData/etudes/ATAG/2025/769509/EPRS\_ATA(2025)769509\_EN.pdf
* Trump EO on fair banking access (anti-debanking): https://www.whitehouse.gov/presidential-actions/2025/08/guaranteeing-fair-banking-for-all-americans/

