# Task 2 — Values Audit

## Question 1: Company Mission, Values, Stage, and Aspirations

**Company name:** ClearPath RegTech Pte. Ltd.  
**Incorporated:** Singapore
**Stage:** Series A, raised SGD 6.2 million from a Southeast Asian fintech-focused VC and one strategic investor (a mid-tier regional bank)  

### Mission statement

"To make the governance of AI in financial services legible to regulators, to institutions, and to the people those models affect."

We do not promise to make AI fair or safe. We promise to make it *readable*: auditable, explainable, and honest about its own limitations. We believe the primary failure mode in RegTech is not technical inadequacy but the production of compliance theatre — documentation that satisfies examiners without actually reducing harm.

### Core values

**Epistemic honesty.** Our tools must be able to say "we don't know" and "this model is drifting." A tool that always produces a clean green dashboard is not a compliance tool; it is a liability shield.

**Proportionality.** A community development financial institution (CDFI) and a global bank face genuinely different risk profiles. Our tooling should not impose the governance burden of a G-SIB on a smaller institution, but it should not let a G-SIB hide behind a lightweight framework either.

**Jurisdiction-specificity without jurisdiction-capture.** We respect that Singapore and the United States have made different political choices about AI governance. We encode those choices faithfully. But we flag when those choices diverge, so that a compliance officer at a dual-jurisdiction institution is not lulled into assuming that passing one regime means passing the other.

### What the company is good at

Our genuine technical advantage is in jurisdiction-aware configuration management for model risk: we have built tooling that versions regulatory parameters (thresholds, required fields, validation frequencies) alongside model versions, so that a rule change mid-year can be traced to its effect on individual model assessments. Most competitors store regulatory rules as flat configuration files that are not versioned, meaning you cannot reconstruct what rules were in force when a given model decision was made.

We are also good at translating MAS examination requirements into software: two of our founders sat on the other side of the examination table and know what MAS examiners actually look for versus what is written in guidance documents.

### Aspirations

**Revenue (Year 3 target):** SGD 8 million ARR, primarily SaaS licensing to banks and regulated finance companies in Singapore, Hong Kong, and Australia, with a US go-to-market through a channel partnership with a US-based compliance advisory firm.

**Cost structure:** We are deliberately services-light. Our gross margin target is 72%. We do not want to be a consulting firm that happens to sell software.

**Geographic coverage:** Singapore (anchor), Hong Kong and Australia (Year 2), United States (Year 3 via partner). We are intentionally not leading with the EU AI Act market despite its scale, because the EU compliance cycle is long, the sales cycle is longer, and the regulatory text is still being operationalised.

\---

## Question 2: Whose Perspective Does the Tool Serve?

### Primary client: the Chief Compliance Officer (CCO) of a dual-jurisdiction bank

Our paying client is the CCO or Chief Risk Officer of a financial institution that uses AI models in credit decisions and has regulatory obligations in more than one jurisdiction. We do not sell directly to regulators (MAS, OCC), though our outputs are designed to be examination-ready. We do not sell to consumers.

This is a deliberate commercial choice. The CCO has budget authority, a clear problem (examination readiness, regulatory capital consequences of model failures), and the ability to pay. The market for selling directly to regulators is small and slow. The market for consumer-facing tools is crowded and has chronic inability-to-pay problems.

### Tensions I have identified

**The CCO's interest and the consumer's interest are not always aligned.** A CCO wants clean audit trails and defensible documentation. A consumer who was denied a loan based on a drifting model wants the denial reversed and the model corrected. These are different things. Our tool serves the CCO. It incidentally serves consumers to the extent that a well-governed model is more accurate and less biased than an ungoverned one. But we should not pretend that examination readiness equals consumer protection.

Specific evidence of this tension: The Trump-era OCC 2026-13 and the simplified Reg B adverse action standard explicitly reduce the burden on lenders to explain AI-driven denials to consumers. A tool designed purely for US regulatory compliance in 2026 is therefore, by construction, less protective of consumers than the same tool configured for Singapore. We encode both configurations faithfully. But we flag this divergence explicitly in our output: "Note: the adverse action notice generated under US Regulation B 2026 meets regulatory minimum standards but does not meet the explainability standard required by MAS FEAT Principles. If this applicant were located in Singapore, the notice would be legally insufficient."

**What we have not done:** We have not sized the US market in depth. Our US go-to-market is based on the hypothesis that dual-jurisdiction institutions are underserved, not on a bottom-up count of OCC-regulated institutions with Singapore operations. We have sized the Singapore addressable market (approximately 230 MAS-licenced full banks and finance companies) but not the overlap with US operations.

\---

## Question 3: Measuring Genuine Risk or Documenting Compliance?

Our tool does both, in a ratio that depends on which feature you are looking at. The jurisdiction configuration layer is primarily a compliance documentation tool. It records which rules apply, generates examination-ready reports, and produces adverse action notices in the right format. That is documentation.

The model drift detection module is genuinely a risk tool. It monitors live model performance against held-out validation data and flags deterioration before a regulator asks about it. A model can be perfectly compliant with all documentation requirements while performing terribly on the population it encounters in production. Our drift module catches that.

### The specific design choice that reflects this

**Feature included because it improves risk detection, even though it is not required:**

We compute conditional SHAP stability, the degree to which the rank-ordering of feature importances is consistent across demographic subgroups over time. This is not required by OCC 2026-13, MAS 2024, or any regulation I am aware of. We included it because a model whose SHAP values for "debt-to-income" are stable overall but unstable within the low-income segment is telling you something important about data quality or population shift in that segment. A model that produces the right overall approval rate while behaving erratically for a specific subgroup is a fair lending risk that no aggregate metric will catch.

**Feature we chose not to include because it would serve documentation over substance:**

We deliberately did not build a "regulatory checkbox" module that maps each model attribute to a specific regulatory requirement and produces a completion report showing X of Y requirements met. Several competitors offer this. We believe it is harmful: it gives CCOs the impression that compliance is binary (complete or incomplete) rather than a matter of degree and judgment. The OCC does not examine banks using a checklist; it exercises judgment about whether the spirit of model risk management has been met. A checkbox dashboard trains CCOs to optimise for the checkbox, not the spirit.

\---

## Question 4: Who Bears the Cost When the Tool Gets It Wrong?

I identify four failure modes, each with a distinct primary victim:

### 4.1 False Positive (tool incorrectly flags a compliant model as non-compliant)

**What happens:** The bank's CCO, alerted by our tool, triggers an unnecessary model review. This costs the bank 150–200 person-hours of review time and may cause the bank to pull a model from production prematurely, reducing credit availability.

**Who is harmed most:** Consumers who would have received credit under the model that was pulled. In a thin-file or underserved segment, exactly the segment where alternative data models are most valuable, a false positive from our tool could reduce credit access. The bank is inconvenienced; the credit-invisible applicant is harmed.

**Our mitigation:** We calibrate detection thresholds conservatively (we flag for review, not for action) and we require human sign-off before any model is flagged as non-compliant in our system.

### 4.2 False Negative (tool fails to detect a non-compliant or drifting model)

**What happens:** A model deteriorates, perhaps because the post-COVID income distribution in Singapore shifted in ways the 2021 training data did not capture, but our drift monitor does not flag it. The model continues approving and denying applications using stale feature relationships.

**Who is harmed most:** Applicants who are wrongly denied credit they would qualify for, or approved for credit they cannot afford. In the Singapore context, MAS would hold the institution responsible; our tool's failure creates regulatory and financial liability for the bank. But the primary human harm is to the misclassified applicants.

**Why this failure mode is particularly dangerous:** It is invisible. The CCO sees a green dashboard. The model appears to be performing. The harm accumulates quietly until either a regulatory examination or a consumer complaint reveals it.

### 4.3 Performance Drift Under Distribution Shift

**What happens:** The model's overall performance metrics remain acceptable (GINI coefficient above threshold, approval rates stable) but a subgroup has experienced an income shock that makes their historical credit bureau data an unreliable predictor. The model continues to assess them using pre-shock feature weights.

**Who is harmed most:** Members of that subgroup who are now mis-scored. They are denied credit they would actually service, or approved for credit they cannot. The harm is concentrated in precisely the population that is hardest to detect through aggregate monitoring.

**Mitigation in our tool:** Conditional drift monitoring by income quartile and employment type. We surface subgroup-level PSI (Population Stability Index) alongside aggregate PSI, specifically because aggregate stability masks subgroup instability.

### 4.4 Jurisdictional Misconfiguration

**What happens:** A bank's Singapore operations are accidentally assessed against US Regulation B parameters instead of MAS FEAT parameters. The adverse action notices generated are legally insufficient under Singapore law. The model's fairness assessment uses the 4/5ths rule instead of demographic parity, masking a disparity that would fail MAS scrutiny.

**Who is harmed most:** The bank (regulatory enforcement, potential licence implications). But also: the applicants who received legally inadequate adverse action notices and therefore could not effectively challenge their denials.

**Why this is especially dangerous in our tool specifically:** Because we market ourselves on jurisdiction awareness. A misconfiguration failure would be a failure at our core value proposition, not a peripheral feature. We mitigate through mandatory jurisdiction confirmation at model ingestion, separate rule sets that cannot be mixed, and audit log entries that record which jurisdiction config was active at each assessment. But I acknowledge that a misconfiguration bug in our config layer would be very bad.

